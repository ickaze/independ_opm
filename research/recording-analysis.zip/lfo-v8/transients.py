import sys,json,numpy as np
sys.path.insert(0,'lfo-final-investigation');sys.path.insert(0,'lfo-recording-analysis')
from sequence import u,P,align
import analyze
analyze.P=__import__('pathlib').Path('upload/12TRANS.wav');V=json.load(open('lfo-v7/noise.json'));R=[]
for r in json.load(open('lfo-v7/boundaries.json')):
 if r['same']:continue
 i=r['boundary'];v=V[i];T=r['time'];p=v['period'];n0=int(np.ceil((T-v['first_time'])/p));n=n0+np.arange(128);ts=v['first_time']+n*p
 start=float(ts[0]-.001);end=float(ts[-1]+.001);x=analyze.read(start,end)[:,1];origin=int(start*96000)/96000;obs=np.interp(ts,origin+np.arange(len(x))/96000,x)<0;pred=u[(n+v['phase'])%P];bad=np.flatnonzero(obs!=pred)
 # Independently identify the local phase after discarding the first two held values.
 off,bp,vote=align(obs[2:36],np.arange(34));later=u[(np.arange(126)+off)%P]
 rr=dict(boundary=i,before=r['before'],after=r['after'],first_delay_us=float((ts[0]-T)*1e6),bad_indices=bad.tolist(),errors_after_first_two=int(sum(obs[2:]!=pred[2:])),independent_local_phase_matches=(off==(v['phase']+n0+2)%P),independent_prediction_errors=int(sum(later[34:]!=obs[36:])));R.append(rr)
 np.savez(f'lfo-v8/transient_{i:03d}.npz',times=ts,bits=obs,predicted=pred)
open('lfo-v8/transients.json','w').write(json.dumps(R,indent=2));print('boundaries',len(R),'with errors after two',sum(r['errors_after_first_two']>0 for r in R),'local phase matches',sum(r['independent_local_phase_matches'] for r in R));print([r for r in R if r['errors_after_first_two'] or not r['independent_local_phase_matches']])
