import sys,json,numpy as np
sys.path.insert(0,'lfo-final-investigation');from sequence import u,P,phases
c=np.array([11.879772503791713,5.991797285839404,3.0203392607498314,1.5099033629332674,.7548269894720152,.3765940364395017,.18773658076828964,.09403944528073829,.04646949407897359])
v=json.load(open('lfo-v7/noise.json'));bs=json.load(open('lfo-v7/boundaries.json'));am=np.load('lfo-v8/am.npz');t=am['times'];T=float(am['period']);y=am['db'];edges=[1.61]+[r['time'] if not r['same'] else (v[r['boundary']-1]['first_time']+v[r['boundary']]['first_time'])/2 for r in bs]+[64.01]
seg=np.searchsorted(edges,t,side='right')-1;valid=np.array([edges[i]+.03<a<edges[i+1]-.03 for a,i in zip(t,seg)])
t=t[valid];y=y[valid];seg=seg[valid];q=[];a=[];ep=[];ds=[]
for tt,i in zip(t,seg):
 w=v[i];ns=32 if w['nfrq']==31 else 16;cs=int((phases(u[(np.arange(17)*ns)%P])[-1]-16)%P);q.append((w['phase']-cs)*ns%P);eventp=w['period']*16/ns;ep.append(eventp);a.append((tt-T/2-(w['first_time']-w['period']/2))/eventp);ds.append(32-w['nfrq'])
q=np.array(q);a=np.array(a);ep=np.array(ep);ds=np.array(ds);j=np.arange(8);train=seg<64
best=None
for lat in np.arange(-32,32,.125)*1e-6:
 idx=q[train,None]+16*np.floor(a[train,None]+lat/ep[train,None]-j/(8*ds[train,None])).astype(int)-7-j+16*(j>=6);p=c[0]+(1-2*u[idx%P].astype(int))@c[1:];mse=np.mean((p-y[train])**2)
 if best is None or mse<best[0]:best=(mse,lat)
mse,lat=best;idx=q[:,None]+16*np.floor(a[:,None]+lat/ep[:,None]-j/(8*ds[:,None])).astype(int)-7-j+16*(j>=6);pred=c[0]+(1-2*u[idx%P].astype(int))@c[1:];err=pred-y
r=dict(latency_us=lat*1e6,train=int(sum(train)),test=int(sum(~train)),train_rms=float(mse**.5),test_rms=float(np.mean(err[~train]**2)**.5),msb_errors=int(sum(u[idx[~train,0]%P]!=(y[~train]<11.900092016))));print(r);open('lfo-v8/global_model.json','w').write(json.dumps(r,indent=2));np.savez('lfo-v8/global_model.npz',times=t,segment=seg,db=y,pred=pred,residual=err,indices=idx)
