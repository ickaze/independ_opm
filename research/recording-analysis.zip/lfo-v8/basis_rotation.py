import sys,json,numpy as np
sys.path.insert(0,'lfo-final-investigation');from sequence import u,P
R=[r for r in json.load(open('lfo-v7/boundaries.json')) if not r['same'] and r['before']==31]
a=np.array([r['qbefore'] for r in R]);b=np.array([r['qafter'] for r in R]);shifts=np.arange(-8,17);j=np.arange(17);out=[]
for k in range(17):
 S=pow(2,k,P);bb=u[(b[:,None]+S*j)%P];aa=u[(a[:,None,None]+shifts[None,:,None]+S*j)%P]
 dist=np.stack([np.sum(np.roll(aa,r,axis=2)!=bb[:,None,:],axis=2) for r in range(17)],axis=2)
 best=dist.min(axis=(1,2));out.append(dict(basis_power=k,exact=int(sum(best==0)),distances=best.tolist()));print(k,int(sum(best==0)))
open('lfo-v8/basis_rotation.json','w').write(json.dumps(out,indent=2))
