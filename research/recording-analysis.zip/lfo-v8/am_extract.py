import sys,json,numpy as np
from pathlib import Path
from scipy.signal import hilbert,resample_poly,find_peaks
sys.path.insert(0,'lfo-recording-analysis');import analyze
analyze.P=Path('upload/12TRANS.wav');start=1.7;end=63.9;x=analyze.read(start,end)[:,0];origin=int(start*96000)/96000;fs=96000
# The AM carrier has no PM; fit phase over the central part of a one-second window.
z=hilbert(x[:fs]);phase=np.unwrap(np.angle(z));t=np.arange(fs)/fs;f=np.polyfit(t[5000:-5000],phase[5000:-5000],1)[0]/(2*np.pi)
analytic=hilbert(x);env=resample_poly(abs(analytic),1,12);db=-20*np.log10(np.maximum(env/.03072093545,1e-6));peaks,_=find_peaks(abs(np.diff(db)),height=.5,distance=70);peaks=peaks[(peaks>800)&(peaks<len(db)-800)]
T=.016384*json.load(open('lfo-v7/clock.json'))['scale'];times=peaks/8000;weights=np.minimum(abs(np.diff(db))[peaks],10);ph=np.angle(np.sum(weights*np.exp(2j*np.pi*times/T)))*T/(2*np.pi);coherence=abs(np.sum(weights*np.exp(2j*np.pi*times/T)))/sum(weights)
centers=np.arange(ph+T/2,end-start-.01,T);centers=centers[centers>.01];amp=[]
for c in centers:
 a=int((c-.003)*fs);b=int((c+.003)*fs);tt=np.arange(a,b)/fs;X=np.array([np.sin(2*np.pi*f*tt),np.cos(2*np.pi*f*tt),np.ones(len(tt))]).T;co=np.linalg.lstsq(X,x[a:b],rcond=None)[0];amp.append(-20*np.log10(np.hypot(co[0],co[1])/.03072093545))
np.savez('lfo-v8/am.npz',times=centers+origin,db=amp,period=T,carrier=f,coherence=coherence)
print('carrier',f,'period',T,'coherence',coherence,'points',len(centers))
