import sys,json,numpy as np
from pathlib import Path
sys.path.insert(0,'lfo-final-investigation');sys.path.insert(0,'lfo-recording-analysis')
from sequence import u,P,phases
import analyze
analyze.P=Path('upload/12TRANS.wav');D=Path('lfo-v7');v=json.load(open(D/'noise.json'));s=[a for a in json.load(open('lfo-transition-test/schedule/12TRANS.json')) if a['analyze']];R=[]
def state(v,T):
 S=2 if v['nfrq']==31 else 1;cs=int((phases(u[(np.arange(17)*S)%P])[-1]-16)%P)
 idx=int(np.floor((T-(v['first_time']-v['period']/2))/v['period']));return ((v['phase']-cs+idx)*S)%P
for i in range(1,128):
 expected=1.615+(s[i]['start_s']-2.29376)*1.0001
 a,b=v[i-1],v[i]
 if a['nfrq']==b['nfrq']:
  dt=(b['first_time']-a['first_time'])/a['period'];r=dict(boundary=i,before=a['nfrq'],after=b['nfrq'],same=True,residue=(b['phase']-a['phase']-round(dt))%P);R.append(r);continue
 start=expected-.05;x=analyze.read(start,expected+.05)[:,1];start=int(start*96000)/96000;ts=start+np.arange(len(x))/96000;obs=x<0;costs=[]
 for w in [a,b]:
  pos=(ts-(w['first_time']-w['period']/2))/w['period'];pred=u[(np.floor(pos).astype(int)+w['phase'])%P];weight=((pos%1)>.25)&((pos%1)<.75);costs.append((pred!=obs)*weight)
 cost=np.cumsum(costs[0])+np.cumsum(costs[1][::-1])[::-1];ks=np.flatnonzero(cost==cost.min());T=float(ts[ks[len(ks)//2]])
 r=dict(boundary=i,before=a['nfrq'],after=b['nfrq'],same=False,time=T,min_time=float(ts[ks[0]]),max_time=float(ts[ks[-1]]),cost=int(cost.min()),qbefore=state(a,T),qafter=state(b,T));R.append(r)
(D/'boundaries.json').write_text(json.dumps(R,indent=2));print('same',[(r['before'],r['residue']) for r in R if r['same']]);print('changed',len([r for r in R if not r['same']]),'cost max',max(r.get('cost',0) for r in R))
