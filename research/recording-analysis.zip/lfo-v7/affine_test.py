import sys,json,numpy as np
sys.path.insert(0,'lfo-final-investigation');from sequence import u,P
rows=[r for r in json.load(open('lfo-v7/boundaries.json')) if not r['same'] and r['before']==31]
def state(q):return sum(int(u[(q-j)%P])<<j for j in range(17))
xs=[state(r['qbefore'])|(1<<17) for r in rows];ys=[state(r['qafter']) for r in rows]
basis={};inconsistent=[];train=32
for i,(x,y) in enumerate(zip(xs[:train],ys[:train])):
 while x:
  k=x.bit_length()-1
  if k not in basis:basis[k]=(x,y);break
  a,b=basis[k];x^=a;y^=b
 if not x and y:inconsistent.append(i)
def pred(x):
 y=0
 while x:
  k=x.bit_length()-1
  if k not in basis:return None
  a,b=basis[k];x^=a;y^=b
 return y
yp=[pred(x) for x in xs];te=[(p^y).bit_count() for p,y in zip(yp[train:],ys[train:])]
r=dict(model='single affine map of the candidate 17-bit state at midpoint changepoint',train=train,test=len(rows)-train,rank=len(basis),inconsistent_training_rows=len(inconsistent),test_exact_matches=sum(e==0 for e in te),test_bit_errors=sum(te),test_bits=17*len(te),boundary_test_ids=[r['boundary'] for r in rows[train:]])
print(r);open('lfo-v7/affine_test.json','w').write(json.dumps(r,indent=2))
