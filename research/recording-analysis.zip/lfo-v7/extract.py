import sys,json,numpy as np
from pathlib import Path
from scipy.optimize import minimize_scalar
sys.path.insert(0,'lfo-recording-analysis');sys.path.insert(0,'lfo-final-investigation')
import analyze
from sequence import u,P,align
analyze.P=Path('upload/12TRANS.wav');D=Path('lfo-v7')
s=[v for v in json.load(open('lfo-transition-test/schedule/12TRANS.json')) if v['analyze']]
windows=[]
for i,v in enumerate(s):
 mid=1.615+((v['start_s']+v['end_s'])/2-2.29376)*1.0001;start=mid-.09;x=analyze.read(start,start+.18)[:,1];origin=int(start*96000)/96000
 ix=np.where(np.signbit(x[:-1])!=np.signbit(x[1:]))[0];cross=(ix+abs(x[ix])/(abs(x[ix])+abs(x[ix+1])))/96000
 windows.append((i,int(v['registers']['0F'])&31,origin,x,cross))
# Common clock scale: sum per-window phase coherence, without assuming phase continuity.
def objective(scale):
 return np.mean([abs(np.exp(2j*np.pi*t/(16e-6*(16 if n==0 else 1)*scale)).mean()) for _,n,_,_,t in windows])
grid=np.linspace(.9997,1.0001,401);b=grid[np.argmax([objective(v) for v in grid])];res=minimize_scalar(lambda v:-objective(v),bounds=(b-2e-6,b+2e-6),method='bounded',options={'xatol':1e-13});scale=res.x;print('scale',scale,flush=True)
R=[]
for i,n,origin,x,cross in windows:
 p=16e-6*(16 if n==0 else 1)*scale;ph=np.angle(np.exp(2j*np.pi*cross/p).mean())*p/(2*np.pi)
 centers=np.arange(ph+p/2,.17,p);centers=centers[centers>.01];bits=np.interp(centers,np.arange(len(x))/96000,x)<0
 off,_,vote=align(bits[:128],np.arange(128));pred=u[(np.arange(len(bits))+off)%P];errors=int(sum(pred!=bits))
 r=dict(segment=i,nfrq=n,first_time=float(origin+centers[0]),period=p,phase=off,samples=len(bits),errors=errors);R.append(r)
 np.savez(D/f'noise_{i:03d}.npz',times=origin+centers,bits=bits,period=p,phase=off,nfrq=n)
 if errors:print('errors',i,errors,flush=True)
(D/'noise.json').write_text(json.dumps(R,indent=2));(D/'clock.json').write_text(json.dumps(dict(scale=scale,score=-res.fun)))
print('total',sum(r['samples'] for r in R),'errors',sum(r['errors'] for r in R))
