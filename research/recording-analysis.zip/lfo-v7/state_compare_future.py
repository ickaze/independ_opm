import sys,json,numpy as np,collections
sys.path.insert(0,'lfo-final-investigation');from sequence import u,P
R=[]
for r in json.load(open('lfo-v7/boundaries.json')):
 if r['same']:continue
 a,b=r['qbefore'],r['qafter'];best=[]
 for shift in range(-8,17):
  aa=u[(a+shift+np.arange(17))%P];bb=u[(b+np.arange(17))%P];diff=np.flatnonzero(aa!=bb).tolist();best.append((len(diff),shift,diff))
 r['best']=sorted(best)[:4];R.append(r)
for direction in [0,31]:
 rows=[r for r in R if r['before']==direction];print(direction,collections.Counter(r['best'][0][0] for r in rows));print([(r['boundary'],r['best'][0]) for r in rows])
open('lfo-v7/state_compare_future.json','w').write(json.dumps(R,indent=2))
