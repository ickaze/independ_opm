import sys,json,numpy as np,collections
sys.path.insert(0,'lfo-final-investigation');from sequence import u,P
R=[]
for r in json.load(open('lfo-v7/boundaries.json')):
 if r['same'] or r['before']!=31:continue
 best=None
 for direction in [-1,1]:
  bb=u[(r['qafter']+direction*np.arange(17))%P]
  for shift in range(-8,17):
   aa=u[(r['qbefore']+shift+direction*np.arange(17))%P]
   for k in range(17):
    d=int(sum(np.roll(aa,k)!=bb))
    if best is None or d<best[0]:best=(d,direction,shift,k)
 R.append(dict(boundary=r['boundary'],best=best))
print(collections.Counter(r['best'][0] for r in R));print(R)
open('lfo-v7/rotation.json','w').write(json.dumps(R,indent=2))
