import sys,wave,json,numpy as np
from pathlib import Path
sys.path.insert(0,'lfo-recording-analysis');import analyze
analyze.P=Path('upload/12TRANS.wav')
with wave.open(str(analyze.P)) as w:
 N=w.getnframes();fs=w.getframerate();print(w.getparams(),N/fs);w.setpos(N-100);assert len(w.readframes(100))==600
r=[]
for start in np.arange(0,N/fs,1):
 x=analyze.read(start,min(start+1,N/fs));m=len(x)//960;r.extend(np.sqrt(np.mean(x[:m*960].reshape(m,960,2)**2,axis=1)))
r=np.array(r);on=r.max(axis=1)>.0001;e=np.diff(np.r_[False,on,False].astype(int));print([(a*.01,b*.01) for a,b in zip(np.where(e==1)[0],np.where(e==-1)[0]) if b-a>3]);np.save('lfo-v7/rms.npy',r)
s=json.load(open('lfo-transition-test/schedule/12TRANS.json'));print([(v['label'],v['start_s'],v['end_s']) for v in s if v['analyze']][:4])
