from pathlib import Path
import wave,json,os
import numpy as np
P=Path(os.environ.get('RANDOM_LFO_WAV','upload/combined/00_07.wav'))
def read(a,b):
 with wave.open(str(P),'rb') as w:
  fs=w.getframerate();w.setpos(max(0,int(a*fs)));raw=w.readframes(int((b-a)*fs))
 v=np.frombuffer(raw,np.uint8).reshape(-1,3).astype(np.int32)
 v=v[:,0]+(v[:,1]<<8)+(v[:,2]<<16);v=(v^0x800000)-0x800000
 return v.reshape(-1,2)/8388608
if __name__=='__main__':
 with wave.open(str(P),'rb') as w:fs=w.getframerate();n=w.getnframes();print(w.getparams(),n/fs)
 rms=[];peak=[]
 for a in range(int(n/fs)+1):
  x=read(a,min(a+1,n/fs));m=len(x)//960
  if m:rms.extend(np.sqrt(np.mean(x[:m*960].reshape(m,960,2)**2,axis=1)));peak.append(float(abs(x).max()))
 rms=np.array(rms);np.save('lfo-recording-analysis/rms.npy',rms)
 active=rms.max(axis=1)>0.0001
 edges=np.diff(np.r_[False,active,False].astype(int));spans=[(a*.01,b*.01) for a,b in zip(np.where(edges==1)[0],np.where(edges==-1)[0]) if b-a>=3]
 print('peak',max(peak));print('spans',spans)
 Path('lfo-recording-analysis/spans.json').write_text(json.dumps(spans))
