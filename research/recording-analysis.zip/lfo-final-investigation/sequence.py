import numpy as np
P=131071
u=np.zeros(P,dtype=np.uint8);u[0]=1
for n in range(17,P):u[n]=u[n-14]^u[n-17]
lut=np.full(P+1,-1,dtype=np.int32);state=0
for n in range(P+16):
 state=((state<<1)|int(u[n%P]))&P
 if n>=16:lut[state]=n%P
assert (lut[1:]>=0).all()
def phases(bits):
 s=0;out=np.full(len(bits),-1,dtype=np.int32)
 for n,bit in enumerate(bits):
  s=((s<<1)|int(bit))&P
  if n>=16:out[n]=lut[s]
 return out
def align(bits,indices):
 ph=phases(bits);valid=(ph>=0)&(np.diff(indices,prepend=indices[0])<=1)
 for k in np.where(np.diff(indices)>1)[0]:valid[k+1:k+17]=False
 vals=(ph[valid]-indices[valid])%P;off=int(np.bincount(vals,minlength=P).argmax())
 return off,u[(indices+off)%P],float(np.mean(vals==off))
